from setuptools import setup

setup(name='arpsls',
      version='1.2',
      description='game',
      packages=['arpsls'],
      author = 'Andrej Cop Prek',
      author_email = 'andrej.prek91@gmail.com',
      zip_safe=False)