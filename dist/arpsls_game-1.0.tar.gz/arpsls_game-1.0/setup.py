from setuptools import setup

setup(name='arpsls_game',
      version='1.0',
      description='game',
      packages=['arpsls_game'],
      author = 'Andrej Cop Prek',
      author_email = 'andrej.prek91@gmail.com',
      zip_safe=False)